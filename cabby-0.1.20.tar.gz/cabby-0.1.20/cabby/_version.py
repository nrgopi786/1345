"""
Version module.
This module defines the package version for use in __init__.py and setup.py.
"""

__version__ = '0.1.20'
