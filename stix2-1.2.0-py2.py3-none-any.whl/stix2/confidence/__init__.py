"""
Functions to operate with STIX2 Confidence scales.

.. autosummary::
   :toctree: confidence

   scales

|
"""
